/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 198145
#define R_NICK "Action of the Toes"
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "3"
#define R_MINOR  "6.1"
#define R_STATUS ""
#define R_YEAR   "2019"
#define R_MONTH  "07"
#define R_DAY    "05"
#define R_SVN_REVISION 76782
#define R_FILEVERSION    3,61,76782,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
